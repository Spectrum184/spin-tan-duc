<?php
session_start();
//host name
define('HOST_NAME_LOCAL', 'localhost');
define('HOST_NAME_ZUMEN', 'ZUMENSERVER-HP');

// database name
define('DB_NAME_DRAW', "document");
define('DB_NAME_PROD', "spin");
define('DB_NAME_PROD_ZUMEN', "production_control");

// username
define('USERNAME_PROD', 'sonobe');
define('USERNAME_TEST', 'root');

//password
define('PASS_PROD', "snb2016");
define('PASS_TEST', "");

// path of drawing folder
define("DRAWING_PATH", "//ZUMENSERVER-HP/document/");


// $path is the path to the pdf file
function showPDF($path)
{
    if ($path) {
        header("Content-type: application/pdf");
        header("Content-Disposition: inline; filename=filename.pdf");
        @readfile($path);
    }
}
