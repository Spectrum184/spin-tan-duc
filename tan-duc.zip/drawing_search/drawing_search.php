<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="icon" type="image/png" href="../assets/favicon.ico" />
    <title>図面検索</title>
</head>

<body>
    <?php require_once('../components/navbar.php');
    require_once('../config/config.php');
    require_once('../components/search_bar.php');
    ?>
    <h3 class="page-title"> 図面検索</h3>
    <div class="container">
        <div class="row">
            <div class="barcode-search">
                <form action="drawing_search.php" method="GET">
                    <?php searchInput('製品番号', '検索') ?>
                </form>
            </div>
        </div>
        <?php if (isset($_GET['search'])) : ?>
            <div class="container">
                <div class="row">
                    <div class="result__header">
                        <div class="header-title col-md-1 col-4">図面 ID</div>
                        <div class="header-title col-md-2 col-1">図面番号</div>
                        <div class="header-title col-md-3 col-1">名称</div>
                        <div class="header-title col-md-1 col-1">設変</div>
                        <div class="header-title col-md-1 col-1">得意先 </div>
                        <div class="header-title col-md-2 col-1">登録日 </div>
                        <div class="header-title col-md-2 col-2">更新日</div>
                    </div>
                    <?php $pro_no = strtoupper(trim($_GET['search'], ' '));
                    //$mysqli = new mysqli(HOST_NAME_LOCAL, USERNAME_TEST, PASS_TEST, DB_NAME_DRAW) or die(mysqli_error($mysqli));
                    $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_DRAW) or die(mysqli_error($mysqli));

                    $result = $mysqli->query("SELECT * FROM drawing_master WHERE Title LIKE '%$pro_no%' AND Activate = 'True' ORDER BY Title LIMIT 100") or die(mysqli_error($mysqli));
                    ?>

                    <?php if ($result->num_rows > 0) : ?>
                        <?php while ($row = $result->fetch_assoc()) : ?>
                            <div class="row mt-2">
                                <div class="result-content">
                                    <div class="result-content__req col-md-1 col-4"><a href="<?= DRAWING_PATH . $row['FileName'] ?>.<?= $row['Prefix'] ?>" target="_blank"><?= $row['Id'] ?></a></div>
                                    <div class="result-content__req col-md-2 col-1"><?php echo $row['Title'] ?></div>
                                    <div class="result-content__req col-md-3 col-1"><?php echo $row['ExtProdName'] ?></div>
                                    <div class="result-content__req col-md-1 col-1"><?php echo $row['ExtChgNo'] ?></div>
                                    <div class="result-content__req col-md-1 col-1"><?php echo $row['ExtCustCd'] ?></div>
                                    <div class="result-content__req col-md-2 col-2"><?php echo $row['AddDate'] ?></div>
                                    <div class="result-content__req col-md-2 col-1"><?php echo $row['UpdateDate'] ?></div>
                                </div>
                            </div>
                        <?php endwhile ?>
                    <?php else : ?>
                        <center>
                            <h5 style="font-weight: 400;"> この製品番号は対応する図面がありません！</h5>
                        </center>
                    <?php endif ?>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <?php require_once('../components/footer.php') ?>

</body>

</html>