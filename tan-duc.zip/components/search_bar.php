<?php
function searchInput($title, $btnName)
{
    echo '
    <div class="search">
    <div class="input-group mb-3 input-search">
        <span class="input-group-text" id="inputGroup-sizing-default">' . $title . '</span>
        <input onmousemove="this.focus()" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="search" placeholder="ここに入力してください">
    </div>
    <div style="margin-left: 4px;" class="ml-2">
        <button type="submit" class="btn-search btn btn-primary">' . $btnName . '</button>
    </div>
</div>';
}
