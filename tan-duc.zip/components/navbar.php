<php? <div>
    <nav class="nav-bar">
        <div class="container">
            <div class="row">
                <div class="nav-bar__content">
                    <div class="nav-title">
                        <a href="../index.php" class="nav-title__link">
                            <h2>園 部 製 作 所</h2>
                        </a>
                    </div>
                    <div class="nav-link">
                        <h4 class="nav-link__title">生産管理</h4>
                        <ul class="nav-list">
                            <li class="nav-list__item"><a class="nav-title__link-menu manager" href="../drawing_search/drawing_search.php">図面検索</a></li>
                            <li class="nav-list__item"><a class="nav-title__link-menu manager" href="../product_manage/component_info.php">構成品在庫状況</a></li>
                            <li class="nav-list__item"><a class="nav-title__link-menu manager" href="../product_manage/order_info.php">製品受注状況</a></li>
                            <li class="nav-list__item"><a class="nav-title__link-menu " onclick="openMultipleTabs(linkManagerArr)" id="manager-link" target="_blank">全て開く</a></li>

                        </ul>
                    </div>
                    <div class="nav-link">
                        <h4 class="nav-link__title">出荷管理</h4>
                        <ul class="nav-list">
                            <li class="nav-list__item"><a class="nav-title__link-menu export" href="../export/location_search.php">ロケーション検索</a></li>
                            <li class="nav-list__item"><a class="nav-title__link-menu export" href="../export/product_confirm.php">製品確認</a></li>
                            <li class="nav-list__item"><a class="nav-title__link-menu " onclick="openMultipleTabs(linkExportArr)" id="export-link" target="_blank">全て開く</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    </div>

    <script>
        var linkManager = document.querySelectorAll(".nav-list__item .manager");
        var linkExport = document.querySelectorAll(".nav-list__item .export");
        var linkManagerArr = [];
        var linkExportArr = [];
        linkManager.forEach(function(link) {
            linkManagerArr.push(link.href);
        });
        console.log(linkManagerArr);
        linkExport.forEach(link => linkExportArr.push(link.href));

        function openMultipleTabs(linkArr) {


            linkArr.forEach(function(url) {
                let link = document.createElement('a');
                link.href = url;
                link.target = '_blank';
                link.click();
            });


        }
    </script>