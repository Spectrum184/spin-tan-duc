<php? <div class="footer">
    <h6>Copyright © Sonobe Manufacture Company 2019-<?php echo date('Y') ?></h6>
    </div>