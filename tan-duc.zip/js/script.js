var idProduct;

function addLocation() {
  document.getElementById("title-add").style.display = "block";
  document.getElementById("add").style.display = "block";
}

function hideFormAdd() {
  document.getElementById("add").style.display = "none";
  document.getElementById("title-add").style.display = "none";
}

function deleteLocate(id) {
  document.getElementById("delete").style.display = "block";
  idProduct = id;
}

function hideDeleteLocate() {
  document.getElementById("delete").style.display = "none";
}

function deleteConfirm() {
  var theUrl1 = "process.php?delete=" + idProduct;
  window.location.replace(theUrl1);
}

function editLocate(id) {
  var theUrl2 = "location_search.php?edit=" + id;
  window.location.replace(theUrl2);
}

function hideFormEdit() {
  window.location.replace("location_search.php");
}
