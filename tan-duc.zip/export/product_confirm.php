<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="icon" type="image/png" href="../assets/favicon.ico" />
    <title>製品確認</title>
</head>

<body>
    <?php require_once("../components/navbar.php");
    require_once('../config/config.php');
    ?>
    <h3 class="page-title"> 製品確認</h3>
    <div class="container">
        <div class="row">
            <div class="barcode-search">
                <form action="product_confirm.php" method="post">
                    <div class="input-group mb-3 select-group">
                        <span class="input-group-text" id="inputGroup-sizing-default">得意先</span>
                        <select name="customerId" id="customerId" class="customer-select">
                            <option value="5001">三菱ふそう: 5001</option>
                            <option value="5017">日立建機: 5017</option>
                        </select>
                    </div>
                    <div class="input-group mb-3 input-search">
                        <span class="input-group-text" id="inputGroup-sizing-default">バーコード</span>
                        <input onmousemove="this.focus()" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="confirm" placeholder="ここに入力してください">
                        <button onclick="closeW()" type="submit" class="btn-search btn btn-primary">確認</button>
                    </div>
                </form>
            </div>
        </div>
        <?php
        if (isset($_POST['confirm'])) : ?>
            <?php
            $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
            //$mysqli = new mysqli('localhost', 'root', '', 'spin') or die(mysqli_error($mysqli));
            $customer_code = trim($_POST['customerId'], " ");
            $order_no_tmp =  trim($_POST['confirm'], " ");
            $order_no = "";
            $strlen = strlen($order_no_tmp);
            $fileName = null;

            if ($customer_code == 5001) {
                if ($strlen == 16) {
                    if (strtoupper($order_no_tmp[0]) === 'A') {
                        $order_no = substr($order_no_tmp, 0, 8);
                    } else if (strtoupper($order_no_tmp[0]) === 'B') {
                        $order_no = substr($order_no_tmp, 0, 7);
                    } else {
                        echo "注文番号のフォーマットが間違っています！もう一同チェックしてお願いいたします。";
                        echo "<br>";
                    }
                } else {
                    echo "注文番号のフォーマットが間違っています！もう一同チェックしてお願いいたします。";
                    echo "<br>";
                }
            } else if ($customer_code == 5017) {
                if ($strlen == 12) {
                    $order_no = substr($order_no_tmp, 2, 8);
                } else {
                    echo "注文番号のフォーマットが間違っています！もう一同チェックしてお願いいたします。";
                    echo "<br>";
                }
            } else {
                echo "注文番号のフォーマットが間違っています！もう一同チェックしてお願いいたします。";
                echo "<br>";
            }

            if (!empty($order_no)) {

                $result = $mysqli->query("SELECT * FROM order_master WHERE Order_No = '$order_no' AND Delv=(SELECT MAX(Delv) FROM order_master WHERE Order_No= '$order_no')") or die(mysqli_error($mysqli));
                $row = $result->fetch_assoc();
                $pro_no = $row['Prod_No'];
                //$mysqli = new mysqli(HOST_NAME_LOCAL, USERNAME_TEST, PASS_TEST, DB_NAME_PROD);
                $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN);
                if ($result->num_rows > 0) {
                    $result4 = $mysqli->query("SELECT * FROM product_location WHERE Pro_No='$pro_no' ORDER BY Building_No DESC") or die(mysqli_error($mysqli));
                }

            ?>

            <?php

                // connect to zumen server to get identify picture
                //$mysqli = new mysqli(HOST_NAME_LOCAL, USERNAME_TEST, PASS_TEST, DB_NAME_DRAW) or die(mysqli_error($mysqli));
                $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_DRAW) or die(mysqli_error($mysqli));
                $result2 = $mysqli->query("SELECT * FROM drawing_master WHERE Title = '$pro_no' AND IdentifyActivate = 'true'") or die(mysqli_error($mysqli));
                $row3 = $result2->fetch_array();
                $IdenFl = null;
                if ($pro_no) {
                    if ($row3[0]) {
                        $tmp = $row3[0];
                        while (strlen($tmp) < 12) {
                            $tmp = "0" . $tmp;
                        }
                        $fileName = '//ZUMENSERVER-HP/identify/' . $tmp . "." . $row3[1];
                        $IdenFl = 1;
                    } else {
                        $fileName = '//ZUMENSERVER-HP/identify/erraa.pdf';
                        $IdenFl = 2;
                    }
                } else {
                    echo "注文番号に対応する製品が探せませんでした!" . "<br>";
                    echo "<br>";
                }
            } else {
                echo "注文番号がよめませんでした！もう一度入力してお願いいたします。<br>";
            }

            ?>
            <?php if (!empty($row)) : ?>
                <?php $_SESSION['link_image'] = $fileName ?>
                <input id="file-name" type="hidden" value="<?php echo $fileName ?>">
                <div class="container">
                    <div class="row barcode-search">
                        <div class="input-group mb-3 prod-no__group">
                            <form action="location_search.php" method="POST">
                                <div class="input-group mb-3 input-search">
                                    <span class="input-group-text" id="inputGroup-sizing-default">対象製品</span>
                                    <input readonly type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-default" name="search" value=<?php echo $row['Prod_No'] ?>>
                                    <button onclick="closeW()" type="submit" class="btn-search btn btn-primary">ロケーション管理</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="row">
                <div class="screen-image">
                    <?php if (isset($fileName)) : ?>
                        <div class="frame-image">
                            <iframe src="<?php echo $fileName ?>" frameborder="0" width="400px" height="300px" style="border: none;"></iframe>
                        </div>
                    <?php endif; ?>
                    <div class="frame-details">
                        <?php if (!empty($order_no)) : ?>
                            <?php if (($result4->num_rows > 0)) : ?>
                                <?php $array_2d = array() ?>
                                <p style="font-size:1.4rem;font-weight:400;">*製品ロケーション</p>
                                <table class="table table-bordered">
                                    <thead class="table-light">
                                        <tr>
                                            <th scope="col">棟</th>
                                            <th scope="col">階</th>
                                            <th scope="col">列</th>
                                            <th scope="col">番</th>
                                            <th scope="col">段</th>
                                            <th scope="col">ノート</th>
                                            <th scope="col">数量</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($row4 = $result4->fetch_array()) : ?>
                                            <tr>
                                                <td> <?php echo $row4['Building_No'] ?></td>
                                                <td> <?php echo $row4['Floor_No'] ?></td>
                                                <td> <?php echo $row4['Row_Locate'] ?></td>
                                                <td> <?php echo $row4['No_Locate'] ?></td>
                                                <td> <?php echo $row4['Shelf'] ?></td>
                                                <td> <?php echo $row4['Note'] ?></td>
                                                <td> <?php echo $row4['Qty'] ?></td>
                                            </tr>
                                            <?php array_push($array_2d, $row4); ?>

                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                                <?php $_SESSION['locations'] = $array_2d; ?>
                            <?php else : ?>
                                <div class="result-notify"><?php echo "この製品は今入っていません！" ?></div>
                            <?php endif ?>
                        <?php endif ?>
                    </div>
                </div>
            </div>

            <?php
            // Update Identify Flag. 
            // $mysqli = new mysqli('ZUMENSERVER-HP', 'sonobe', 'snb2016', 'Production_control') or die(mysqli_error($mysqli));
            // $mysqli = new mysqli('localhost', 'root', '', 'spin') or die(mysqli_error($mysqli));
            // $mysqli->query("UPDATE order_master set IdentifyFG = '$IdenFl' where Order_No = '$order_no") or die(mysqli_error($mysqli));
            ?>
        <?php endif; ?>
    </div>
    <?php
    require_once('../components/footer.php')
    ?>
    <script>
        // open picture 
        var sonobe;
        window.onload = function openW() {
            if (document.getElementById("file-name")) {
                var tmp = "product_details.php";
                var params = "width=" + screen.width;
                params += ",height=" + screen.height;
                params += "menubar=yes,location=yes,resizable=yes,scrollbars=yes,status=yes";
                params += "top=0,left=1000"
                sonobe = window.open(tmp, 'sonobe', params);
            }
        }

        //close picture
        window.onbeforeunload = function closeW() {
            if (sonobe) {
                sonobe.close();
            }
        }
    </script>
</body>

</html>