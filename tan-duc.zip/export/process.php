<?php
require_once('../config/config.php');
//$mysqli = new mysqli(HOST_NAME_LOCAL, USERNAME_TEST, PASS_TEST, DB_NAME_PROD) or die(mysqli_error($mysqli));
$mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));

if (session_id() === '') session_start();

$update = false;
$showEdit = 'none';
$id = 0;
$Pro_No = '';
$Building_No = '';
$Floor_No = '';
$Row_Locate = '';
$No_Locate = '';
$Shelf = '';
$Note  = '';
$Qty  = '';

// add more product location
if (isset($_POST['add-locate'])) {
	$Pro_No =  trim($_POST['Pro_No'], " ");
	$Building_No = strlen($_POST['Building_No']) ? ((int)$_POST['Building_No']) : 0;
	$Floor_No =   strlen($_POST['Floor_No']) ? ((int)$_POST['Floor_No']) : 0;
	$Row_Locate =   trim($_POST['Row_Locate'], " ");
	$No_Locate = trim($_POST['No_Locate'], " ");
	$Shelf = strlen($_POST['Shelf']) ? ((int)$_POST['Shelf']) : 0;
	$Note  = trim($_POST['Note'], " ");
	$Qty  =  strlen($_POST['Qty']) ? ((int)$_POST['Qty']) : 0;

	//check value by int type and null or not

	if (($Building_No != 0) && ($Floor_No != 0)) {
		$locateResult = $mysqli->query("SELECT * FROM product_location WHERE Pro_No='$Pro_No' AND Building_No = '$Building_No' AND Floor_No = '$Floor_No' AND Row_Locate = '$Row_Locate' AND No_Locate = '$No_Locate' AND Shelf='$Shelf'") or die(mysqli_error($mysqli));
		if ($locateResult->num_rows == 0) {
			$mysqli->query("INSERT INTO product_location (Pro_No, Building_No, Floor_No, Row_Locate, No_Locate, Shelf, Note, Qty) VALUES ('$Pro_No', '$Building_No', '$Floor_No', '$Row_Locate', '$No_Locate', '$Shelf', '$Note', '$Qty')") or die(mysqli_error($mysqli));

			$_SESSION['message'] = "新しいロケーション保存しました！!";
			$_SESSION['msg-type'] = "success";
			header("location: location_search.php?search=$Pro_No");
		} else {
			$_SESSION['message'] = "同じいロケーションがあります!";
			$_SESSION['msg-type'] = "warning";
			header("location: location_search.php?search=$Pro_No");
		}
	} else {
		$_SESSION['message'] = "正しく入力してください!";
		$_SESSION['msg-type'] = "danger";
		header("location: location_search.php?search=$Pro_No");
	}
}

// delete product location
if (isset($_GET['delete'])) {
	$id = $_GET['delete'];
	$result = $mysqli->query("SELECT * FROM product_location WHERE ID = '$id'") or die(mysqli_error($mysqli));
	$mysqli->query("DELETE FROM product_location WHERE ID = '$id'") or die(mysqli_error($mysqli));
	$row = $result->fetch_array();
	$_SESSION['message'] = $row[1] . "のロケーションを削除しました!";
	$_SESSION['msg-type'] = "success";
	header("location: location_search.php?search=$row[1]");
}

//get product location from database for editting
if (isset($_GET['edit'])) {
	$id = $_GET['edit'];
	$result = $mysqli->query("SELECT * FROM product_location WHERE ID = '$id'") or die(mysqli_error($mysqli));
	if ($result->num_rows > 0) {
		$update = true;
		$showEdit = 'block';
		$row = $result->fetch_array();
		$Pro_No = $row['Pro_No'];
		$Building_No = $row['Building_No'];
		$Floor_No = $row['Floor_No'];
		$Row_Locate = $row['Row_Locate'];
		$No_Locate = $row['No_Locate'];
		$Shelf = $row['Shelf'];
		$Note  = $row['Note'];
		$Qty  = $row['Qty'];
	}
}

//update product location
if (isset($_POST['update-locate'])) {
	$id = $_POST['id'];
	$Pro_No =  trim($_POST['Pro_No'], " ");
	$Building_No = strlen($_POST['Building_No']) ? ((int)$_POST['Building_No']) : 0;
	$Floor_No =   strlen($_POST['Floor_No']) ? ((int)$_POST['Floor_No']) : 0;
	$Row_Locate =   trim($_POST['Row_Locate'], " ");
	$No_Locate = trim($_POST['No_Locate'], " ");
	$Shelf = strlen($_POST['Shelf']) ? ((int)$_POST['Shelf']) : 0;
	$Note  = trim($_POST['Note'], " ");
	$Qty  =  strlen($_POST['Qty']) ? ((int)$_POST['Qty']) : 0;
	//check value by int type

	if (($Building_No != 0) && ($Floor_No != 0)) {
		$mysqli->query("UPDATE product_location SET Pro_No = '$Pro_No', Building_No = '$Building_No', Floor_No = '$Floor_No', Row_Locate = '$Row_Locate',  No_Locate = '$No_Locate', Shelf ='$Shelf', Note = '$Note',  Qty = '$Qty' WHERE ID = '$id'") or die(mysqli_error($mysqli));

		$_SESSION['message'] = "完了しました!";
		$_SESSION['msg-type'] = "success";
		header("location: location_search.php?search=$Pro_No");
	} else {
		$_SESSION['message'] = "正しく入力してください!";
		$_SESSION['msg-type'] = "danger";
		header("location: location_search.php?edit=$id");
	}
}
