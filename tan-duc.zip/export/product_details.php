<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/styles.css">
    <title>製品情報</title>
    <link rel="icon" type="image/png" href="../assets/favicon.ico" />
</head>

<body>
    <?php require_once("../components/navbar.php");
    require_once("../config/config.php");
    ?>
    <div class="screen-image" style="margin-top: 70px;">
        <?php if (isset($_SESSION['link_image'])) : ?>
            <div class="frame-image">
                <iframe src="<?php echo $_SESSION['link_image'] ?>" frameborder="0" width="900px" height="600px" style="border: none;"></iframe>
            </div>
        <?php endif; ?>
        <div class="frame-detail">
            <?php if (isset($_SESSION['locations'])) : ?>
                <p style="font-size:1.4rem;font-weight:400;">*製品ロケーション</p>
                <table class="table table-bordered">
                    <thead class="table-light ">
                        <tr>
                            <th scope="col">棟</th>
                            <th scope="col">階</th>
                            <th scope="col">列</th>
                            <th scope="col">番</th>
                            <th scope="col">段</th>
                            <th scope="col">ノート</th>
                            <th scope="col">数量</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($_SESSION['locations'] as $location => $content) : ?>
                            <tr>
                                <td> <?php echo $content['Building_No'] ?></td>
                                <td> <?php echo $content['Floor_No'] ?></td>
                                <td> <?php echo $content['Row_Locate'] ?></td>
                                <td> <?php echo $content['No_Locate'] ?></td>
                                <td> <?php echo $content['Shelf'] ?></td>
                                <td> <?php echo $content['Note'] ?></td>
                                <td> <?php echo $content['Qty'] ?></td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            <?php else : ?>
                <div class="result-notify"><?php echo "この製品は今入っていません！" ?></div>
            <?php endif ?>
        </div>
    </div>

    <?php
    session_unset();
    require_once('../components/footer.php')
    ?>
</body>

</html>