<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="../css/styles.css">
	<link rel="icon" type="image/png" href="../assets/favicon.ico" />
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
	<title>ロケーション検索</title>
</head>

<body>
	<?php require_once("../components/navbar.php");
	require_once('process.php');
	require_once('../components/search_bar.php');
	require_once('../config/config.php')
	?>
	<!-- notification -->
	<?php if (isset($_SESSION['message'])) : ?>
		<div class="alert alert-<?= $_SESSION['msg-type'] ?>">
			<div class="container" style="margin-top: 60px;">
				<div class="row">
					<?php
					echo $_SESSION['message'];
					unset($_SESSION['message']);
					?>
				</div>
			</div>
		</div>
		<center>
			<h3>ロケーション管理</h3>
		</center>
	<?php else : ?>
		<h3 class="page-title"> ロケーション管理</h3>
	<?php endif; ?>
	<div class="container">
		<div class="row">
			<div class="barcode-search">
				<form action="location_search.php" method="post">
					<?php searchInput($title = "バーコード", $btnName = "検索") ?>
				</form>
			</div>
			<div class="btn-add__locate">
				<?php if ($update == false) : ?>
					<button type="button" class="btn add-location btn-info" onclick="addLocation()">新しいロケーション</button>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php
	if (isset($_POST['search']) || isset($_GET['search'])) :
	?>
		<div class="container mt-3">
			<div class="row">
				<div class="result__header">
					<div class="header-title col-md-2 col-4">製品番号</div>
					<div class="header-title col-md-1 col-1">棟</div>
					<div class="header-title col-md-1 col-1">階</div>
					<div class="header-title col-md-1 col-1">列</div>
					<div class="header-title col-md-1 col-1">番</div>
					<div class="header-title col-md-1 col-1">段</div>
					<div class="header-title col-md-2 col-2">ノート</div>
					<div class="header-title col-md-1 col-1">数量</div>
					<div class="header-title col-md-2" style="text-align: center;">行動</div>
				</div>
			</div>
			<?php
			//mysqli = new mysqli(HOST_NAME_LOCAL, USERNAME_TEST, PASS_TEST, DB_NAME_PROD) or die(mysqli_error($mysqli));
			$mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
			if (isset($_POST['search'])) {
				$pro_no =  trim($_POST['search'], " ");
			} else {
				$pro_no = trim($_GET['search'], " ");
			}
			$result = $mysqli->query("SELECT * FROM product_location WHERE Pro_No LIKE'%$pro_no%' ORDER BY Building_No DESC") or die(mysqli_error($mysqli));
			?>
			<?php if ($result->num_rows == 0) : ?>
				<div class="row">
					<div class="result-notify"><?php echo "この製品は今入っていません！" ?></div>
				</div>
			<?php else : ?>
				<?php while ($row = $result->fetch_assoc()) : ?>
					<div class="row mt-2">
						<div class="result-content">
							<div class="result-content__req col-md-2 col-4"><?php echo $row['Pro_No'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php echo $row['Building_No'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php echo $row['Floor_No'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php echo $row['Row_Locate'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php echo $row['No_Locate'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php if ($row['Shelf'] == 0) echo "";
																			else echo $row['Shelf'] ?></div>
							<div class="result-content__req col-md-2 col-2"><?php echo $row['Note'] ?></div>
							<div class="result-content__req col-md-1 col-1"><?php echo $row['Qty'] ?></div>
							<div class="result-content__req col-md-2">
								<div class="btn-action">
									<a href="location_search.php?edit=<?php echo $row['ID'] ?>" type="button" class="btn btn-success tb-btn">変更</a>
									<button onclick="deleteLocate(<?php echo $row['ID'] ?>)" type="button" class="btn-delete btn btn-danger">削除</button>
								</div>
							</div>
						</div>
						<div class="btn-action__mobile col-12 ">
							<a href="location_search.php?edit=<?php echo $row['ID'] ?>" type="button" class="btn btn-success tb-btn">変更</a>
							<button onclick="deleteLocate(<?php echo $row['ID'] ?>)" type="button" class="btn-delete btn btn-danger">削除</button>
						</div>
					</div>
				<?php endwhile; ?>
			<?php endif; ?>
		</div>

		</div>
	<?php endif; ?>
	<div class="container mt-3">
		<div class="row">
			<h4 class="title-add" id="title-add">* 新しいロケーションを加えます:</h4>
			<h4 class="title-add" style="display: <?php echo $showEdit ?>;" id="title-edit">* 情報編集：</h4>
		</div>
	</div>
	<!-- form add location and modify location -->
	<div class="add-locate" id="add" name="modify" style="display: <?php echo $showEdit ?>;">
		<div class="container mt-2">
			<div class="row">
				<form action="process.php" method="POST" id="form-locate">
					<input type="hidden" name="id" value="<?php echo $id ?>">
					<div class="form-add">
						<div class="form-add__item col-lg-2 col-md-6 col-12">
							<div class="form-add__header">
								製品番号
							</div>
							<div class="form-add_content">
								<input <?php if ($update == true) : echo 'readonly' ?><?php endif; ?> onmousemove="this.focus()" value="<?php echo $Pro_No ?>" name="Pro_No" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								棟
							</div>
							<div class="form-add_content">
								<input value="<?php echo $Building_No ?>" name="Building_No" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								階
							</div>
							<div class="form-add_content">
								<input value="<?php echo $Floor_No ?>" name="Floor_No" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								列
							</div>
							<div class="form-add_content">
								<input value="<?php echo $Row_Locate ?>" name="Row_Locate" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								番
							</div>
							<div class="form-add_content">
								<input value="<?php echo $No_Locate ?>" name="No_Locate" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								段
							</div>
							<div class="form-add_content">
								<input value="<?php if ($row['Shelf'] == 0) echo "";
												else echo $row['Shelf'] ?>" name="Shelf" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-2 col-md-6 col-12">
							<div class="form-add__header">
								ノート
							</div>
							<div class="form-add_content">
								<input value="<?php echo $Note ?>" name="Note" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-1 col-md-2 col-6">
							<div class="form-add__header">
								数量
							</div>
							<div class="form-add_content">
								<input value="<?php echo $Qty ?>" name="Qty" type="text" class="form-control" aria-label="Sizing example input" aria-describedby="inputGroup-sizing-sm">
							</div>
						</div>
						<div class="form-add__item col-lg-2 col-md-4 col-12">
							<div class="form-add__header">
								行動
							</div>
							<div class="form-add_content">
								<div class="btn-action">
									<?php if ($update == true) : ?>
										<button type="submit" class="btn btn-info" name="update-locate">保存</button>
										<button onclick="hideFormEdit()" type="button" class="btn-delete btn btn-warning">キャンセル</button>
									<?php else : ?>
										<button type="submit" class="btn btn-info" name="add-locate">加える</button>
										<button onclick="hideFormAdd()" type="button" class="btn-delete btn btn-warning">キャンセル</button>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<!-- font confirm delete location -->
	<div class="delete-locate" id="delete">
		<div class="modal-delete modal-dialog">
			<div class="modal-content">
				<div class="modal-header">
					<h5 class="modal-title" id="" name="idProductDelete">削除</h5>
					<button onclick="hideDeleteLocate()" type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
				</div>
				<div class="modal-body">
					本当に削除しますか?
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-secondary" data-bs-dismiss="modal" onclick="hideDeleteLocate()">閉じる</button>
					<button type="button" onclick="deleteConfirm()" class="btn btn-primary" name="delete">同意</button>
				</div>
			</div>
		</div>
	</div>
	<?php
	require_once('../components/footer.php')
	?>
	<script src="../js/script.js"></script>
	<script>
		var inputProNo = document.querySelector(".add-locate");
		inputProNo.addEventListener('keydown', function(event) {
			if (event.keyCode === 13 && event.target.nodeName === 'INPUT') {
				var form = event.target.form;
				var index = Array.prototype.indexOf.call(form, event.target);
				form.elements[index + 1].focus();
				event.preventDefault();
			}
		});
	</script>
</body>

</html>