<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="icon" type="image/png" href="../assets/favicon.ico" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <title>構成品在庫状況</title>
</head>

<body>
    <?php require_once('../config/config.php');
    require_once('../components/navbar.php');
    require_once('../components/search_bar.php')
    ?>
    <h3 class="page-title"> 構成品在庫状況</h3>
    <div class="container">
        <div class="row">
            <div class="barcode-search">
                <form action="component_info.php" method="post">
                    <div class="input-group mb-3 select-group">
                        <span class="input-group-text" id="inputGroup-sizing-default">得意先</span>
                        <select name="customerId" id="customerId" class="customer-select">
                            <option value="5001">三菱ふそう: 5001</option>
                            <option value="5017">日立建機: 5017</option>
                        </select>
                    </div>
                    <?php searchInput('製品番号', '検索'); ?>
                </form>
            </div>
        </div>
    </div>
    <?php if (isset($_POST['search'])) : ?>
        <?php
        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
        $customID = $_POST['customerId'];
        $Product_No = $_POST['search'];
        //search for the product's storage status
        $result1 = $mysqli->query("SELECT Prod_Parts_No,Prod_Parts_Name,stock,L_StkIn_Date,L_StkOut_Date FROM product_parts_master 
        LEFT JOIN unitsinstock_table ON unitsinstock_table.Cust_CD=product_parts_master.Cust_CD AND Prod_Parts_No=Prod_No AND Prod_Div='0' 
        where product_parts_master.Cust_CD='$customID' and Prod_Parts_No='$Product_No';");
        //search for the product's future product plan
        $result2 = $mysqli->query("SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
        WHERE Cust_CD='$customID' AND Prod_No='$Product_No' and Comp_FG!=1;");


        $PROD_STAT = '';
        ?>
        <div class="container ">
            <?php if ($result1->num_rows == 0) : ?>
                <div class="row">
                    <div class="result-notify"><?php echo "この製品番号は製品に対応しません！" ?></div>
                </div>
            <?php else : ?>
                <div class="row">
                    <?php while ($row1 = $result1->fetch_assoc()) : ?>
                        <?php while ($row2 = $result2->fetch_assoc()) {
                            if (empty($PROD_STAT)) {
                                $PROD_STAT = date("m-d", strtotime($row2['Req_Due_Date'])) . "/" . $row2['Prod_Plan_Qty'];
                            } else {
                                $PROD_STAT = $PROD_STAT . "\n" . date("m-d", strtotime($row2['Req_Due_Date'])) . "/" . $row2['Prod_Plan_Qty'];
                            }
                        }

                        ?>
                        <div class="result__header mt-2">
                            <div class="table-index-title col-md-1 col-1">製品番号</div>
                            <div class="table-index col-md-1 col-1"><?php echo $row1['Prod_Parts_No'] ?></div>
                            <div class="table-index-title col-md-1 col-1">部品名称</div>
                            <div class="table-index col-md-1 col-1"><?php echo $row1['Prod_Parts_Name'] ?></div>
                            <div class="table-index-title col-md-1 col-1">在庫</div>
                            <div class="table-index col-md-1 col-1"><?php echo $row1['stock'] ?></div>
                            <div class="table-index-title col-md-1 col-1">最終入庫</div>
                            <div class="table-index col-md-1 col-1"><?php echo $row1['L_StkIn_Date'] ?></div>
                            <div class="table-index-title col-md-1 col-1">最終出庫</div>
                            <div class="table-index col-md-1 col-1"><?php echo $row1['L_StkOut_Date'] ?></div>
                            <div class="table-index-title col-md-1 col-1">仕掛状況</div>
                            <div class="table-index col-md-1 col-1"><?php echo $PROD_STAT ?></div>
                        </div>
                    <?php endwhile; ?>
                </div>
            <?php endif; ?>
        </div>

        </div>
        <div class="container mt-2" style="margin-bottom: 40px;">
            <table class="table table-hover caption-top table-bordered">

                <caption>
                    <div class="caption">
                        <h5>製品の部品 &nbsp;
                            &#8627: とは以上の部品の部品；
                            <span style="background-color: #ffff00;">黄色</span>の行とは支給品です。
                        </h5>
                    </div>
                </caption>
                <thead>
                    <tr>
                        <th scope="col">部品番号</th>
                        <th scope="col">部品名称</th>
                        <th scope="col">使用数</th>
                        <th scope="col">在庫</th>
                        <th scope="col">最終入庫</th>
                        <th scope="col">最終出庫</th>
                        <th scope="col">格納場所</th>
                        <th scope="col">完了工程</th>
                        <th scope="col">仕掛状況</th>
                    </tr>
                </thead>
                <tbody>

                    <?php
                    function component_search($customID, $Product_No, $flag)
                    {
                        //search for the product's components and their storage status
                        $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
                        $result3 = $mysqli->query("SELECT Parts_Cust_CD,Parts_No,Prod_Parts_Name,Product_div,Used_Qty,stock,L_StkIn_Date,L_StkOut_Date FROM (component_master 
                        left join product_parts_master on Cust_CD=Parts_Cust_CD and Prod_Parts_No=Parts_No) 
                        left join unitsinstock_table on unitsinstock_table.Cust_CD=Parts_Cust_CD and Parts_No=Prod_No 
                        where Assy_Cust_CD='$customID' and Assy_No='$Product_No';") or die(mysqli_error($mysqli));
                        if ($result3->num_rows > 0) {
                            $flag += 1;
                        }
                        while ($row3 = $result3->fetch_assoc()) {
                            if (($row3['Product_div'] == "S2")) {
                                echo "<tr bgcolor='#FFFF00'>";
                            }

                            $space = $flag * 3;

                            if ($space === 0) {
                                echo "<td>" . $row3['Parts_No'] . "</td>";
                            } else {
                                echo "<td>";
                                while ($space > 0) {
                                    echo "&nbsp";
                                    $space = $space - 1;
                                }
                                echo "<span class='arrow-symbol'>&#8627</span>" . $row3['Parts_No'] . "</td>";
                            }

                            echo "<td>" . $row3['Prod_Parts_Name'] . "</td>";
                            echo "<td>" . $row3['Used_Qty'] . "</td>";
                            echo "<td>" . $row3['stock'] . "</td>";
                            echo "<td>" . $row3['L_StkIn_Date'] . "</td>";
                            echo "<td>" . $row3['L_StkOut_Date'] . "</td>";

                            //search for the part's storage location
                            $result4 = $mysqli->query("SELECT Location FROM location_master 
                                WHERE Cust_CD='{$row3['Parts_Cust_CD']}' AND Parts_No='{$row3['Parts_No']}';");
                            if (isset($result4)) {
                                echo "<td>";
                                if ($result4->num_rows > 1) {
                                    while ($row4 = mysqli_fetch_assoc($result4)) {
                                        echo $row4['Location'];
                                        echo "<br>";
                                    }
                                } else {
                                    while ($row4 = mysqli_fetch_assoc($result4)) {
                                        echo $row4['Location'];
                                    }
                                }
                                echo "</td>";
                            }
                            $result5 = $mysqli->query("SELECT Abbre_Proc_name FROM prod_process_master AS ppm
                                    INNER JOIN (SELECT Cust_CD,Parts_NO,Max(Proc_No) AS MAX_P_NO FROM prod_process_master        
                                    GROUP BY Cust_CD,Parts_NO) AS s1 
                                    ON ppm.Cust_CD=s1.Cust_CD AND ppm.Parts_NO=s1.Parts_NO AND ppm.Proc_No=s1.MAX_P_NO        
                                    LEFT JOIN process_master ON ppm.Proc_CD=process_master.Proc_CD
                                    WHERE ppm.Cust_CD='{$row3['Parts_Cust_CD']}' AND ppm.Parts_NO='{$row3['Parts_No']}';");
                            if (isset($result5)) {
                                echo "<td>";

                                while ($row5 = $result5->fetch_assoc()) {
                                    echo $row5['Abbre_Proc_name'];
                                }

                                echo "</td>";
                            }
                            $result6 = $mysqli->query("SELECT Req_Due_Date,Prod_Plan_Qty FROM productplan_table 
                                    WHERE Cust_CD='{$row3['Parts_Cust_CD']}' AND Prod_No='{$row3['Parts_No']}' and Comp_FG!=1;");
                            if (isset($result6)) {
                                echo "<td>";
                                if ($result6->num_rows > 1) {
                                    while ($row6 = $result6->fetch_assoc()) {
                                        echo $row6['Req_Due_Date'] . " " . $row6['Prod_Plan_Qty'] . "<br>";
                                    }
                                } else {
                                    while ($row6 = $result6->fetch_assoc()) {
                                        echo $row6['Req_Due_Date'] . " " . $row6['Prod_Plan_Qty'];
                                    }
                                }
                                echo "</td>";
                            }
                            echo "</tr>";
                            if (isset($row3['Parts_No']))
                                component_search($customID, $row3['Parts_No'], $flag);
                        }
                    }

                    $flag = -1;
                    component_search($customID, $Product_No, $flag); ?>

                </tbody>
            </table>

        </div>

    <?php endif; ?>
    <?php
    require_once('../components/footer.php')
    ?>
</body>

</html>