<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/styles.css">
    <link rel="icon" type="image/png" href="../assets/favicon.ico" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <title>製品受注状況</title>
</head>

<body>
    <?php require_once('../config/config.php');
    require_once('../components/navbar.php');
    require_once('../components/search_bar.php')
    ?>
    <h3 class="page-title"> 製品受注状況</h3>
    <div class="container">
        <div class="row">
            <div class="barcode-search">
                <form action="order_info.php" method="post">
                    <div class="input-group mb-3 select-group">
                        <span class="input-group-text" id="inputGroup-sizing-default">得意先</span>
                        <select name="customerId" id="customerId" class="customer-select">
                            <option value="5001">三菱ふそう: 5001</option>
                            <option value="5017">日立建機: 5017</option>
                        </select>
                    </div>
                    <?php searchInput('製品番号', '検索'); ?>
                </form>
            </div>
        </div>
    </div>
    <?php if (isset($_POST['search'])) : ?>
        <div class="container ">
            <div class="row">
                <div class="note">
                    <div style="background-color: #f3a7e6; width:fit-content; display: block;" class="color-square">この色 </div>
                    <div class="">
                        <span>: というのは未納製品があります!!</span>
                    </div>
                </div>
                <div class="result__header mt-2">
                    <div class="header-title col-md-2 col-2">注番</div>
                    <div class="header-title col-md-2 col-2">工事番号</div>
                    <div class="header-title col-md-2 col-2">納期</div>
                    <div class="header-title col-md-1 col-1">受注数</div>
                    <div class="header-title col-md-1 col-1">未納数</div>
                    <div class="header-title col-md-1 col-1">納場</div>
                    <div class="header-title col-md-1 col-1">次工程</div>
                    <div class="header-title col-md-2 col-2">登録日</div>
                </div>
            </div>
            <?php
            $DAY = Date('Y-m-d', strtotime("- 3 month"));
            $mysqli = new mysqli(HOST_NAME_ZUMEN, USERNAME_PROD, PASS_PROD, DB_NAME_PROD_ZUMEN) or die(mysqli_error($mysqli));
            $Prod_No_Search =  trim($_POST['search'], " ");
            $Cust_CD_Search = $_POST['customerId'];
            $result = $mysqli->query("SELECT * FROM order_master WHERE Cust_CD='$Cust_CD_Search' AND Prod_No='$Prod_No_Search' AND Delv>'$DAY' ORDER BY Delv DESC;") or die(mysqli_error($mysqli));
            ?>
            <?php if ($result->num_rows == 0) : ?>
                <div class="row">
                    <div class="result-notify"><?php echo "この製品は3ヶ月以内受注がありません！" ?></div>
                </div>
            <?php else : ?>
                <?php while ($row = $result->fetch_assoc()) : ?>
                    <?php if ($row['Order_Qty'] - $row['Delv_Qty'] != 0) {
                        $tmp = $row['Order_Qty'] - $row['Delv_Qty'];
                    } else {
                        $tmp = 0;
                    } ?>
                    <div class="row mt-2">
                        <div style=" background-color:<?php if ($tmp > 0) {
                                                            echo '#f3a7e6';
                                                        } else {
                                                            echo '#FFF';
                                                        } ?>" class="result-content">
                            <div class="result-content__req col-md-2 col-2"><?php echo $row['Order_No'] ?></div>
                            <div class="result-content__req col-md-2 col-2"><?php echo $row['Job_No'] ?></div>
                            <div class="result-content__req col-md-2 col-2"><?php echo $row['Delv'] ?></div>
                            <div class="result-content__req col-md-1 col-1"><?php echo $row['Order_Qty'] ?></div>
                            <div class="result-content__req col-md-1 col-1"><?php echo $tmp ?></div>
                            <div class="result-content__req col-md-1 col-1"><?php echo $row['Delv_Point'] ?></div>
                            <div class="result-content__req col-md-1 col-1"><?php echo $row['Fol_Proc'] ?></div>
                            <div class="result-content__req col-md-2 col-2"><?php echo $row['Entry_Date'] ?></div>
                        </div>
                    </div>
                <?php endwhile; ?>

            <?php endif; ?>
        </div>
    <?php endif; ?>
    <?php
    require_once('../components/footer.php')
    ?>
</body>

</html>